﻿namespace Pong
{
    partial class FormMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPvP = new System.Windows.Forms.Button();
            this.btnPvE = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnPvP
            // 
            this.btnPvP.Location = new System.Drawing.Point(272, 187);
            this.btnPvP.Name = "btnPvP";
            this.btnPvP.Size = new System.Drawing.Size(75, 23);
            this.btnPvP.TabIndex = 0;
            this.btnPvP.Text = "Pvp";
            this.btnPvP.UseVisualStyleBackColor = true;
            this.btnPvP.Click += new System.EventHandler(this.btnPvP_Click);
            // 
            // btnPvE
            // 
            this.btnPvE.Location = new System.Drawing.Point(272, 262);
            this.btnPvE.Name = "btnPvE";
            this.btnPvE.Size = new System.Drawing.Size(75, 23);
            this.btnPvE.TabIndex = 1;
            this.btnPvE.Text = "PvE";
            this.btnPvE.UseVisualStyleBackColor = true;
            this.btnPvE.Click += new System.EventHandler(this.btnPvE_Click);
            // 
            // FormMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnPvP);
            this.Controls.Add(this.btnPvE);
            this.Name = "FormMenu";
            this.Text = "FormMenu";
            this.Load += new System.EventHandler(this.FormMenu_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnPvP;
        private System.Windows.Forms.Button btnPvE;
    }
}