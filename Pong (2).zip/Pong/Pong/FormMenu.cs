﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pong
{
    public partial class FormMenu : Form
    {
        public FormMenu()
        {
            InitializeComponent();
            this.StartPosition= FormStartPosition.CenterScreen;
        }

        private void FormMenu_Load(object sender, EventArgs e)
        {

        }

        private void btnPvP_Click(object sender, EventArgs e)
        {
            Form1 game = new Form1(false);
            game.ShowDialog();
            this.Show();
        }

        private void btnPvE_Click(object sender, EventArgs e)
        {
        Form1 game = new Form1(true);
        game.ShowDialog();
        this.Show();
        

        
        }

    }
}
