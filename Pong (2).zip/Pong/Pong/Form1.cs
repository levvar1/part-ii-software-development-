﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pong
{
    public partial class Form1 : Form
    {
        bool IsWithAI;

        //игровые объекты 
        int leftPaddleY = 200;//левая ракетка 
        int rightPaddleY = 200;//правая рокетка 

        int ballSpeedX = 10;
        int ballSpeedY = 10;
        int leftscore = 0;
        int rightscore = 0;
        bool fameRunning = true;
        int ballX;
        int ballY;
        string winner = "";
        Timer timer;//таймер анимации
        bool leftUp, leftDown, rightUp, rightDown;
        int paddleSpeed = 10;
        public Form1( bool aiMode)
        {
            InitializeComponent();
            IsWithAI = aiMode;
            //настройка формы 
            this.Text = "PongGame";//устанавливаем имя окна 
            this.Size = new Size(800, 600);//размер окна
            this .StartPosition= FormStartPosition.CenterParent;//устанавливает местоположения окна по центру
            this.DoubleBuffered = true;//убираем мерцания
            this.KeyPreview = true;//свойства которое позволяет приложению первым получать события с клавиатуры 
            timer = new Timer();
            timer.Interval = 20;
            timer.Tick +=(s,e)=> UpdateGame();
            timer.Start();
            ballX = this.ClientSize.Width / 2;
            ballY=this.ClientSize.Height / 2;
            //подключаем события 
            this.Paint += Form1_Paint;
            this.KeyDown += Form1_KeyDown;//подключаем события нажатия клавиш 
            this.KeyUp += Form1_KeyUp;
            
        }

        //рисование игры 
        private void Form1_Paint(object sender, PaintEventArgs e)
        { 
            Graphics g = e.Graphics;//создаем объект для доступа к элементу рисования 
           
            g.FillRectangle(Brushes.Green, 0, 0,this.Width,this.Height);//заливаем фон 
            Pen whitePen=new Pen(Color.White,3);//создаем белую кисть 
            g.DrawLine(whitePen, this.Width / 2, 0, this.Width / 2, this.Height);//рисуем центральную линию
            g.FillRectangle(Brushes.Black, 30, leftPaddleY, 15, 100);
            g.FillRectangle(Brushes.Black, this.Width-45, rightPaddleY, 15, 100);
            g.FillEllipse(Brushes.Yellow, ballX - 8, ballY - 8, 16, 16);//рисуем мяч
            
            Font font = new Font("Arial", 30);//рисуем счет
            g.DrawString(leftscore.ToString(),font,Brushes.White,this.Width/4,20);//рисуем  левого игрока счет в левом углу 
            g.DrawString(rightscore.ToString(), font, Brushes.White,3 * this.Width / 4, 20);
            if (winner == "left")
            {
                e.Graphics.DrawImage(Image.FromFile("C:\\Users\\лев\\source\\repos\\Pong\\Pong\\win.jpg"), this.Width / 4 - 100, this.Height / 2 - 100, 200, 200);
            }
            if (winner == "right")
            {
                e.Graphics.DrawImage(Image.FromFile("C:\\Users\\лев\\source\\repos\\Pong\\Pong\\win.jpg"), 3*this.Width / 4 - 100, this.Height / 2 - 100, 200, 200);
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e) 
        {

            if (e.KeyCode == Keys.W) leftUp = true;
                if (e.KeyCode == Keys.S) leftDown = true;
                if (e.KeyCode == Keys.Up) rightUp = true;
                if (e.KeyCode == Keys.Down) rightDown = true;
        }
        private void Form1_KeyUp(object sender, KeyEventArgs e) 
        {
            if (e.KeyCode == Keys.W) leftUp = false;
            if (e.KeyCode == Keys.S) leftDown = false;
            if (e.KeyCode == Keys.Up) rightUp = false;
            if (e.KeyCode == Keys.Down) rightDown = false;
        }
        
        private void ResetBall()
        {
            ballX = this.Width/2;
            ballY = this.Height / 2;
            leftPaddleY = 200;
            rightPaddleY = 200;
            ballSpeedX = (new Random().Next(0,2)==0)?10:-10;
        }
        private void UpdateGame()
        {
            if (leftUp && leftPaddleY > 0) leftPaddleY -= paddleSpeed;
            if (leftDown && leftPaddleY < this.Height - 140) leftPaddleY += paddleSpeed;

            
            if (IsWithAI)
            {
                int paddleCenter = rightPaddleY + 50;
                if(ballY>paddleCenter&& rightPaddleY < this.ClientSize.Height)
                {
                    rightPaddleY += (paddleSpeed - 2);
                }
                else if (ballY < paddleCenter && rightPaddleY > 0)
                {
                    rightPaddleY -= paddleSpeed - 2;
                }
            }
            else
            {
                if (rightUp && rightPaddleY > 0) rightPaddleY -= paddleSpeed;
                if (rightDown && rightPaddleY < this.Height - 140) rightPaddleY += paddleSpeed;
            }
            ballX += ballSpeedX;
            ballY += ballSpeedY;
            if(ballY<=0||ballY>=this.ClientSize.Height - 16)
            {
                ballSpeedY = -ballSpeedY;
            }
            Rectangle leftRect=new Rectangle(30,leftPaddleY,15,100);
            Rectangle RightRect = new Rectangle(this.Width - 45, rightPaddleY, 15, 100);
            Rectangle ballRect = new Rectangle(ballX - 8, ballY - 8, 16, 16);
            if (ballRect.IntersectsWith(leftRect) || ballRect.IntersectsWith(RightRect))
            {
                ballSpeedX=-ballSpeedX;
            }
            if (ballX < 0)
            {
                rightscore++;
                checkWin("игрок справа");
              
            }
            if (ballX > this.Width)
            {
                leftscore++;
                checkWin("игрок слева");
               
            }
            this.Invalidate();
        }
        private void checkWin(string name)
        {
            if (leftscore >= 5 || rightscore >= 5)
            {
                timer.Stop();
                winner = (leftscore >= 5) ? "left" : "right";
                this.Refresh();
                MessageBox.Show($"{name} победил поздавляю Это конец вы прошли игру");
                
                this.Close();
            }
            else
            {
                ResetBall();
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
